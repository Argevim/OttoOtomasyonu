﻿namespace Samba.Infrastructure
{
    public interface IStringCompareable
    {
        string GetStringValue();
    }
}
