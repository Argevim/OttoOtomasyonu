﻿namespace Fluentscript.Lib._Core.Meta.Types
{
    public class CustomTag
    {
        public string Name;
        public string Content;
    }
}
