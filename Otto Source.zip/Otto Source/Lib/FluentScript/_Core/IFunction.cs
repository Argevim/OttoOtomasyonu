﻿namespace Fluentscript.Lib._Core
{
    /// <summary>
    /// Interface for a plugin that acts as a function.
    /// </summary>
    interface IPluginFunction
    {
    }
}
