﻿namespace Fluentscript.Lib.AST.Core
{
    /// <summary>
    /// Evaluatable expression
    /// </summary>
    public class EvaluatableExpression : Expr
    {

    }     
}
