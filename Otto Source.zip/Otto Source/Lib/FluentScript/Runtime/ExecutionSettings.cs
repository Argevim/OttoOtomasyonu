﻿namespace Fluentscript.Lib.Runtime
{
    /// <summary>
    /// Settings for the execution.
    /// </summary>
    public class ExecutionSettings
    {

    }
}
