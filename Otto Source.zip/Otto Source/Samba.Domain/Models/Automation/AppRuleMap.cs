﻿using Samba.Infrastructure.Data;

namespace Samba.Domain.Models.Automation
{
    public class AppRuleMap : AbstractMap
    {
        public int AppRuleId { get; set; }
    }
}
