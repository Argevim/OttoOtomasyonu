﻿using Samba.Infrastructure.Data;

namespace Samba.Domain.Models.Entities
{
    public class EntityScreenMap : AbstractMap
    {
        public int EntityScreenId { get; set; }
    }
}
