#SambaPOS Touch Screen POS Software

More Information
http://emreeren.github.com/SambaPOS-3/

Visit www.sambapos.com for stable releases.

Otto project is cloned by Sambapos project. Detail of the Sambapos project at above. Developers should use Otto DB, to develop Otto via Samba Framework.
